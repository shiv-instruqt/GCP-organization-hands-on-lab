# 1.2 Enable the required APIs with gcloud

## Concept: APIs are per project

Every Google Cloud service is an API that must be **enabled in a project** before anything in that project can use it. Enabling an API:

- is done by an identity with `serviceusage.services.enable` (e.g. *Service Usage Admin*),
- can create **service agents** (Google-managed service accounts like `service-PROJECT_NUMBER@gcp-sa-...`),
- makes the API's **quotas** apply to that project,
- is itself an auditable action — so you must always know **which identity** enabled what.

> [!NOTE]
> Calls are charged to a **quota project**. When you impersonate a service account or call Policy Troubleshooter, the API must be enabled in the project of the *calling* credentials — that's why some APIs are needed in both projects.

## Your goal

Enable these APIs — and nothing you don't need (every enabled API is attack surface and quota you have to own):

| Project | API | Needed for |
|---------|-----|-----------|
| dev | `iamcredentials.googleapis.com` | Service-account impersonation (short-lived tokens) |
| dev | `policytroubleshooter.googleapis.com` | Explaining access-denied results (failure drill) |
| dev | `orgpolicy.googleapis.com` | Reading effective org policies |
| staging | `iamcredentials.googleapis.com` | Impersonating the pipeline identity |
| staging | `artifactregistry.googleapis.com` | Pipeline pushes images |
| staging | `run.googleapis.com` | Pipeline deploys to Cloud Run |
| staging | `orgpolicy.googleapis.com` | Reading effective org policies |

Then document every row in `~/week1/02-api-enablement.md`: API, project, why, **which identity** enabled it and the command.

### Step 1 — See what is (and isn't) enabled

List enabled APIs in both projects. Search the catalog for the ones you need.

<details>
<summary>💡 Show step-by-step instructions</summary>

```bash
gcloud --configuration=dev     services list --enabled
gcloud --configuration=staging services list --enabled

# search the catalog of available APIs
gcloud --configuration=dev services list --available --filter="name:run.googleapis.com"
```

Notice a few APIs were already on (Resource Manager, IAM, Service Usage, Cloud Storage). The platform team needed those to vend the project — record them in the "already enabled" section of your notes.

</details>

### Step 2 — Enable the dev APIs

<details>
<summary>💡 Show step-by-step instructions</summary>

```bash
gcloud config configurations activate dev
gcloud config get-value account        # <- the identity that will perform the change

gcloud services enable \
  iamcredentials.googleapis.com \
  policytroubleshooter.googleapis.com \
  orgpolicy.googleapis.com
```

`services enable` is a long-running operation; it returns when done (usually < 1 min).

</details>

### Step 3 — Enable the staging APIs

<details>
<summary>💡 Show step-by-step instructions</summary>

```bash
gcloud config configurations activate staging
gcloud config get-value account

gcloud services enable \
  iamcredentials.googleapis.com \
  artifactregistry.googleapis.com \
  run.googleapis.com \
  orgpolicy.googleapis.com

gcloud services list --enabled --format="value(config.name)" | sort
```

</details>

### Step 4 — Prove who did it

Look at `~/week1/commands.log` — each line shows the configuration, the account and the exit code. Use it to fill `~/week1/02-api-enablement.md`.

<details>
<summary>💡 Show step-by-step instructions</summary>

```bash
grep "services enable" ~/week1/commands.log
```

Optional (Cloud Audit Logs are the authoritative record, may take a few minutes to appear):

```bash
gcloud --configuration=dev logging read \
  'protoPayload.methodName="google.api.serviceusage.v1.ServiceUsage.EnableService"' \
  --limit=5 --format="table(timestamp, protoPayload.authenticationInfo.principalEmail, protoPayload.resourceName)"
```

(If `logging read` is denied, that's expected — your identity doesn't hold *Logs Viewer*. Note it as a least-privilege observation.)

Fill the table: one row per API + project. The *Enabled by* column must contain the platform-admin email.

</details>

## Checklist

<instruqt-task id="t_apis"></instruqt-task>

## Knowledge check

<instruqt-quiz id="quiz_hierarchy"></instruqt-quiz>
