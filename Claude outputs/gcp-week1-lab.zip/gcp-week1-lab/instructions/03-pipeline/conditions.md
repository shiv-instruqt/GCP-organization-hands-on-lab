# 3.2 Time-bound cross-project access with IAM Conditions

## Concept: IAM Conditions

A binding can carry a **condition** written in CEL. The role only applies while the condition is `true`.

| Attribute | Example | Use case |
|-----------|---------|----------|
| `request.time` | `request.time < timestamp("2026-12-01T00:00:00Z")` | Temporary / break-glass access that **expires by itself** |
| `resource.name` | `resource.name.startsWith("projects/_/buckets/reports")` | Limit a project-level grant to some resources |
| `resource.type` | `resource.type == "storage.googleapis.com/Bucket"` | Limit to one kind of resource |

Rules worth remembering:

- Policies with conditions use **policy version 3**.
- Conditions do **not** work with basic roles (owner/editor/viewer).
- A condition can only *restrict* the binding it's on — it never removes access granted elsewhere.

**Project boundaries vs identities:** a service account *lives* in one project but can be granted access in **any** project. `dev-alice` (from dev) has no access to staging until someone with IAM admin rights in **staging** grants it.

## Your goal

QA asked that Alice can **read objects in staging for one week** while she verifies a release — and that the access must disappear automatically.

In the **staging** project, grant `dev-alice` (from **dev**) `roles/storage.objectViewer` **with a condition** that expires **at most 30 days** from now (7 days is the request). Give the condition a title. Alice must have **no unconditional** access in staging.

### Step 1 — Compute an expiry timestamp

<details>
<summary>💡 Show step-by-step instructions</summary>

```bash
EXPIRY=$(date -u -d "@$(( $(date +%s) + 7*24*3600 ))" +%Y-%m-%dT%H:%M:%SZ)
echo "$EXPIRY"
```

(`date -d @EPOCH` works in both BusyBox and GNU date.)

</details>

### Step 2 — Add the conditional binding (as the **staging** platform admin)

<details>
<summary>💡 Show step-by-step instructions</summary>

```bash
gcloud config configurations activate staging

gcloud projects add-iam-policy-binding "$STAGING_PROJECT" \
  --member="serviceAccount:$DEV_ALICE" \
  --role="roles/storage.objectViewer" \
  --condition="expression=request.time < timestamp('$EXPIRY'),title=week1-temporary-access,description=QA verification - expires automatically"
```

Note: the **staging** admin performs this grant. The dev admin couldn't — try it:
`gcloud --configuration=dev projects add-iam-policy-binding "$STAGING_PROJECT" --member="serviceAccount:$DEV_ALICE" --role=roles/storage.objectViewer --condition=None` → `PERMISSION_DENIED`. Project boundary!

</details>

### Step 3 — Inspect the version-3 policy

<details>
<summary>💡 Show step-by-step instructions</summary>

```bash
gcloud projects get-iam-policy "$STAGING_PROJECT" --format=json | grep -B3 -A8 dev-alice
gcloud projects get-iam-policy "$STAGING_PROJECT" --format="value(version)"   # -> 3
```

Optional: ask Policy Troubleshooter whether the condition grants access *now* vs *after expiry*. The caller must be able to read staging's IAM policy, so run it as the **staging** admin (enable the API there first — one more row for your API notes):

```bash
gcloud --configuration=staging services enable policytroubleshooter.googleapis.com

for t in "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "2099-01-01T00:00:00Z"; do
  gcloud --configuration=staging policy-intelligence troubleshoot-policy iam \
    "//cloudresourcemanager.googleapis.com/projects/$STAGING_PROJECT" \
    --principal-email="$DEV_ALICE" --permission=storage.objects.get \
    --request-time="$t" --format="value(overallAccessState)"
done
```

</details>

## Checklist

<instruqt-task id="t_conditions"></instruqt-task>

## Knowledge check

<instruqt-quiz id="quiz_identity"></instruqt-quiz>
