#!/bin/bash
# shellcheck disable=SC1091
source /opt/lab/lib.sh 2>/dev/null || { echo "The lab environment is still being prepared - wait a minute and click Check again."; exit 1; }

ALL_SAS="$DEV_ADMIN_SA $STAGING_ADMIN_SA $DEV_ALICE $CI_DEPLOYER $APP_RUNTIME"
TERMS="appDeveloper run.developer artifactregistry.writer serviceAccountUser serviceAccountTokenCreator storage.objectViewer"
case "$CHECK" in
  identity_map)
    f="$W1/03-identity-map.md"
    [ -f "$f" ] || fail "03-identity-map.md not found."
    for sa in $ALL_SAS; do grep -qF "$sa" "$f" || fail "03-identity-map.md is missing $sa"; done
    no_todo "$f" || fail "03-identity-map.md still contains _TODO_ placeholders." ;;
  least_privilege)
    f="$W1/06-least-privilege.md"
    [ -f "$f" ] || fail "06-least-privilege.md not found."
    for t in $TERMS; do grep -qF "$t" "$f" || fail "06-least-privilege.md does not mention $t"; done
    no_todo "$f" || fail "06-least-privilege.md still contains _TODO_ placeholders." ;;
  command_log)
    c=$(grep -c "gcloud" "$LOG" 2>/dev/null || echo 0)
    [ "$c" -ge 15 ] || fail "commands.log has only $c gcloud commands (need 15+)." ;;
  bundled)
    f="$W1/week1-deliverable.md"
    [ -s "$f" ] || fail "~/week1/week1-deliverable.md not found."
    grep -qF "$CI_DEPLOYER" "$f" || fail "week1-deliverable.md does not contain your identity map."
    grep -qF "acting-as=" "$f"   || fail "week1-deliverable.md does not contain the command log."
    grep -qF "storage.objectViewer" "$f" || fail "week1-deliverable.md does not contain the least-privilege table." ;;
  *) fail "Unknown check '$CHECK'" ;;
esac
exit 0
