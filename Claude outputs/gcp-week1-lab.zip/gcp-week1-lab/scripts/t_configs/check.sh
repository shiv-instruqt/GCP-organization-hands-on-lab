#!/bin/bash
# shellcheck disable=SC1091
source /opt/lab/lib.sh 2>/dev/null || { echo "The lab environment is still being prepared - wait a minute and click Check again."; exit 1; }

cfg_ok() { # cfg_ok <name> <expected-project> <expected-account>
  local p a
  p=$(gcloud config configurations describe "$1" --format="value(properties.core.project)" 2>/dev/null)
  a=$(gcloud config configurations describe "$1" --format="value(properties.core.account)" 2>/dev/null)
  gcloud config configurations describe "$1" >/dev/null 2>&1 || fail "Configuration '$1' does not exist yet."
  [ "$p" = "$2" ] || fail "Configuration '$1' has project '${p:-<unset>}' - expected '$2'."
  [ "$a" = "$3" ] || fail "Configuration '$1' has account '${a:-<unset>}' - expected '$3'."
  gcloud auth list --format="value(account)" 2>/dev/null | grep -qx "$3" \
    || fail "No credentials for $3 - run gcloud auth activate-service-account with its key file."
}

case "$CHECK" in
  dev_config)     cfg_ok dev "$DEV_PROJECT" "$DEV_ADMIN_SA" ;;
  staging_config) cfg_ok staging "$STAGING_PROJECT" "$STAGING_ADMIN_SA" ;;
  hierarchy_notes)
    f="$W1/01-hierarchy.md"
    dn=$(gdev projects describe "$DEV_PROJECT" --format="value(projectNumber)")
    sn=$(gstg projects describe "$STAGING_PROJECT" --format="value(projectNumber)")
    [ -n "$dn" ] && grep -q "$dn" "$f" || fail "The dev project NUMBER is not in 01-hierarchy.md."
    [ -n "$sn" ] && grep -q "$sn" "$f" || fail "The staging project NUMBER is not in 01-hierarchy.md."
    no_todo "$f" || fail "01-hierarchy.md still contains _TODO_ placeholders."
    ;;
  *) fail "Unknown check '$CHECK'" ;;
esac
exit 0
