#!/bin/bash
# shellcheck disable=SC1091
source /opt/lab/lib.sh 2>/dev/null || { echo "The lab environment is still being prepared - wait a minute and click Check again."; exit 1; }

TC=roles/iam.serviceAccountTokenCreator
case "$CHECK" in
  token_creator)
    sa_roles gdev "$DEV_ALICE" "serviceAccount:$DEV_ADMIN_SA" | grep -qx "$TC" \
      || fail "The dev platform-admin does not hold $TC on $DEV_ALICE."
    project_roles gdev "$DEV_PROJECT" "serviceAccount:$DEV_ADMIN_SA" | grep -qx "$TC" \
      && fail "$TC is granted at PROJECT level - that allows impersonating every service account. Remove it and grant on dev-alice only."
    ;;
  object_uploaded)
    gdev storage objects describe "gs://$DEV_BUCKET/hello.txt" --format="value(name)" >/dev/null 2>&1 \
      || fail "gs://$DEV_BUCKET/hello.txt not found." ;;
  impersonated_ok)
    log_ok_as "$DEV_ALICE" || fail "No successful gcloud command acting as $DEV_ALICE in commands.log." ;;
  impersonated_denied)
    log_denied_as "$DEV_ALICE" || fail "No denied command acting as $DEV_ALICE yet - try deleting hello.txt as dev-alice." ;;
  *) fail "Unknown check '$CHECK'" ;;
esac
exit 0
