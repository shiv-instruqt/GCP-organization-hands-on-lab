#!/bin/bash
# shellcheck disable=SC1091
source /opt/lab/lib.sh 2>/dev/null || { echo "The lab environment is still being prepared - wait a minute and click Check again."; exit 1; }

case "$CHECK" in
  token_creator)
    gdev iam service-accounts add-iam-policy-binding "$DEV_ALICE" \
      --member="serviceAccount:$DEV_ADMIN_SA" --role=roles/iam.serviceAccountTokenCreator >/dev/null ;;
  object_uploaded)
    echo "hello from alice" > /root/week1/hello.txt
    gdev storage cp /root/week1/hello.txt "gs://$DEV_BUCKET/hello.txt" ;;
  impersonated_ok)
    log_note 0 "$DEV_ALICE" "gcloud storage ls gs://$DEV_BUCKET --impersonate-service-account=$DEV_ALICE   # (auto-solved)" ;;
  impersonated_denied)
    log_note 1 "$DEV_ALICE" "gcloud storage rm gs://$DEV_BUCKET/hello.txt --impersonate-service-account=$DEV_ALICE   # (auto-solved)" ;;
esac
exit 0
