#!/bin/bash
# shellcheck disable=SC1091
source /opt/lab/lib.sh 2>/dev/null || { echo "The lab environment is still being prepared - wait a minute and click Check again."; exit 1; }

EXPECTED="storage.buckets.get storage.objects.create storage.objects.get storage.objects.list"
ROLE="projects/$DEV_PROJECT/roles/appDeveloper"

case "$CHECK" in
  sa_created)
    sa_exists gdev "$DEV_ALICE" || fail "Service account $DEV_ALICE not found." ;;
  bucket_created)
    gdev storage buckets describe "gs://$DEV_BUCKET" --format="value(name)" >/dev/null 2>&1 \
      || fail "Bucket gs://$DEV_BUCKET not found." ;;
  custom_role)
    have=$(custom_role_perms gdev appDeveloper | sort | xargs)
    [ -n "$have" ] || fail "Custom role appDeveloper not found in $DEV_PROJECT."
    [ "$have" = "$EXPECTED" ] || fail "appDeveloper has [$have] - expected exactly [$EXPECTED]." ;;
  bucket_binding)
    bucket_roles "$DEV_BUCKET" "serviceAccount:$DEV_ALICE" | grep -qx "$ROLE" \
      || fail "dev-alice does not hold $ROLE on gs://$DEV_BUCKET." ;;
  no_project_roles)
    r=$(project_roles gdev "$DEV_PROJECT" "serviceAccount:$DEV_ALICE" | xargs)
    [ -z "$r" ] || fail "dev-alice has project-level role(s): $r - remove them, grant on the bucket only." ;;
  *) fail "Unknown check '$CHECK'" ;;
esac
exit 0
